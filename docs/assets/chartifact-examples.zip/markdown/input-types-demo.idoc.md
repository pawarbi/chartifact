```json vega
{
  "$schema": "https://vega.github.io/schema/vega/v5.json",
  "description": "This is the central brain of the page",
  "signals": [
    {
      "name": "userAge",
      "value": 25
    },
    {
      "name": "salary",
      "value": 50000
    },
    {
      "name": "ageCategory",
      "value": "Young Adult"
    },
    {
      "name": "monthlyIncome",
      "value": 4166.67
    }
  ]
}
```


```css
body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; margin: 0; padding: 20px; background: #f5f7fa; }
.group { background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); margin-bottom: 20px; }
h1 { color: #333; text-align: center; }
h2 { color: #666; margin-top: 30px; }
.result { background: #e8f5e8; padding: 15px; border-radius: 5px; margin-top: 10px; }
.vega-bindings { margin: 10px 0; }
.vega-bind { margin-bottom: 15px; }
.vega-bind-name { display: inline-block; width: 150px; font-weight: bold; }
```


::: group {#header}

# Number Input Demo

This demo showcases the new **number** input type in Chartifact. Try changing the values below to see how they affect the calculated results.
:::
::: group {#inputs}

## Input Controls


```yaml number
variableId: userAge
value: 25
label: Your Age
min: 0
max: 120
step: 1
placeholder: Enter your age
```


```yaml number
variableId: salary
value: 50000
label: Annual Salary ($)
min: 0
max: 1000000
step: 1000
placeholder: Enter annual salary
```


:::
::: group {#results}

## Calculated Results

**Age Category:** {{ageCategory}}

**Monthly Income:** ${{monthlyIncome}}

### Summary
You are **{{userAge}}** years old, categorized as a **{{ageCategory}}**. Your annual salary of **${{salary}}** translates to approximately **${{monthlyIncome}}** per month.
:::